# Boston Globe City Desk Copy — Held from Print (1918)

BOSTON GLOBE — CITY DESK COPY — HELD FROM PRINT

HOUSE ON SHEAFE STREET LEAVES A RECORD OF MISFORTUNE

A dwelling known in the neighborhood as the Corbitt House has acquired a history that no agent's fresh paint can conceal. Successive tenants have departed after accidents, lingering illness, and self-inflicted death. No single public record explains the pattern, but the addresses and dates repeat with uncomfortable regularity.

The Macario family took the house early in 1918 and abandoned it within weeks, leaving no orderly notice. Neighbors disagree about what drove them out. Relatives will say only that members of the family are now receiving care in Roxbury.

The Globe has not established a criminal cause and will not print rumor as fact. The city desk is holding this feature until the property records, hospital accounts, and surviving tenants can be examined together.
