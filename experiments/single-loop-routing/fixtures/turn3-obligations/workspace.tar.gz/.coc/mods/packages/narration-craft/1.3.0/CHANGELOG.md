# Narration Craft

## 1.3.0
- States where the text breaks (docs/specs/delivery-typography.md): a paragraph holds one beat, a person's speech is its own paragraph, a new speaker always starts one, a long speech breaks where its subject turns, and the gesture that frames a speech may stand alone to re-anchor the reader mid-speech. Measured over three campaigns before this existed: 26 of the 35 paragraphs carrying speech also carried a narration beat in the same block, with a tail of four-to-six rendered lines — the shape a reader calls a wall.
- Paragraph length is named as rhythm, never as a quota. No count returns: this is the craft half of a rule whose one-line register form rides in `style.axes` every turn, and neither half is measured by the kernel. `brief.md` is deliberately unchanged — the axis already says it on every turn, and the §30.7 brief ceiling has three bytes left.

## 1.2.0
- States the turn floor as craft (docs/specs/turn-floor.md): uptake, the world's answer, a voice, the handoff; the routine-turn warning returns as craft, not as a budget; a one-word input gets a full turn; `director.offer` is named as what can move when nothing landed; the handoff is the spotlight rule — stop only when the player has enough to judge and more than one real thing to do, never at a midpoint with nothing to decide. Two live tables (medians 167 and 37 characters, 11 of 12 turns closed by the host with no tool call) showed that 1.1.0's retirement of the ladder had also retired the only floor language.
- Adds `density_guide` (`off` | `on`, default `off`): with `on`, the brief carries the play language's expected density per beat as an expectation the kernel never counts. No `*_chars` ceilings and no paragraph caps return.

## 1.1.0
- Retires the length ladder and its settings: `settings` and `settings_schema` are now empty. The character ceilings never bound anything — twenty measured deliveries ran 52–430 characters against ceilings of 600–1500 (contract §30.8) — and 1.0.2 had already dropped the paragraph caps beside them.
- Drops the rule that a concrete handle must be in reach before stopping, the required trailing question, and the instruction to give a cost its own block of prose. Action uptake and keep-the-fact move to the base layer, which owns the definition of a playable turn.
- Owns, instead, what is craft: selecting material from the live exchange and the `present[]` dossier, NPC voice, crisis ordering, the scene-opening perception offered rather than required, the beat words with their humour knobs, and the world-assertion cost ladder.
- Friendly help, companionship, a joke and a quiet scene are complete outcomes; plain telling is allowed; one detail may serve several purposes; hidden truth stays hidden by reference to law 3 rather than restated (contract §30.12).

## 1.0.2
- Drops the paragraph caps (the `*_paragraphs` settings). Twenty measured deliveries ran 1–9 paragraphs against caps of 3–8, exceeding them in eight of eleven while never approaching the character ceiling (contract §30.8). This entry was missing when 1.0.2 shipped in commit `317a5991`, which bumped `mod.json` alone.

## 1.0.1
- Adds `brief.md`, the per-turn reminder form of the instructions (contract §30.7); the first turn of a process still carries the full text.

## 1.0.0
- First release: beat-keyed length budget as settings, action uptake, world-assertion cost, crisis order, handles before stopping, beat vocabulary and NPC voice openings.
